package com.roma.entity.enumeration;

public enum Role {

	ROLE_ADMIN, ROLE_USER
	
}
