package com.roma.service;

import com.roma.domain.mail.Mail;

public interface EmailService {

	void sendMessage(Mail mail);
	
}
