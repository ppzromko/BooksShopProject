Fully configured SpringBoot application starter project. 
Includes: Spring Security, Apache Tiles, JPA, MySQL, Email service
